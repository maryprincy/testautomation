package stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class delete_repo_steps {

	
	
	@Given("click on repo_name")
	public void click_on_repo_name() {
	
	}
	
	@Then("click on settings")
	public void click_on_settings() {
	   
	}
	
	@Then("click on delete repository")
	public void click_on_delete_repository() {
	   
	}
	
	@And("type the confirmation text")
	public void type_the_confirmation_text() {
	 
	}
	
	@Then("click the delete statement")
	public void click_the_delete_statement() {
	  
	}

}
